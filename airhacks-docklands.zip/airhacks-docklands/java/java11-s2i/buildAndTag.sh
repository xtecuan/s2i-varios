#!/bin/bash

export KAPP_HOME=$(dirname $(realpath $0))
source ${KAPP_HOME}/environment.sh

docker build -t $PROMERICA_JAVA  .
