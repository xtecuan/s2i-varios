#!/bin/bash

export KAPP_HOME=$(dirname $(realpath $0))
source ${KAPP_HOME}/environment.sh


docker build --build-arg VERSION=$PAYMICRO_VERSION   -t  $PROMERICA_PAYMICRO . 
