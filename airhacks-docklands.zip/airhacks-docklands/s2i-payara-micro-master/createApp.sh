#!/bin/bash
export KAPP_HOME=$(dirname $(realpath $0))
source ${KAPP_HOME}/environment.sh


if [ -n "$1" ]
then 
	echo "Creating App $1 from WAR using image  ${IMPORTED_IMAGE}"
	oc new-app ${IMPORTED_IMAGE}:latest~/. --name=$1 --strategy=docker
else
	echo "Usage $0 appname"
fi



