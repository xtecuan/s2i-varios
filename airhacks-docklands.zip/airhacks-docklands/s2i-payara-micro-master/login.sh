#!/bin/bash

export TOKEN=$(oc whoami -t)
export API_HOST=api.ocp01.promnet.com.sv
export API_PORT=6443
export API_URL=https://${API_HOST}:${API_PORT}

oc login --token=${TOKEN} --server=${API_URL}
