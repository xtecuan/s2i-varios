#!/bin/bash

export TOKEN=sha256~33_Us3cJy89GOALPRn2ixAtsTRmNgJuQuC02TewZrXQ
export API_HOST=api.ocp01.promnet.com.sv
export API_PORT=6443
export API_URL=https://${API_HOST}:${API_PORT}

oc login --token=${TOKEN} --server=${API_URL}
