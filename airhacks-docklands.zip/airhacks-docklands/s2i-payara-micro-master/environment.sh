#!/bin/bash


export KAPP_HOME=$(dirname $(realpath $0))

export PAYMICRO_VERSION=5.2022.2
export PROMERICA_JAVA=airhackspromerica/java-s2i
export PROMERICA_PAYMICRO=airhackspromerica/payara-micro-s2i:$PAYMICRO_VERSION
export PROMERICA_S2I=airhackspromerica/s2i-payara-micro-promerica
export IMPORTED_IMAGE=s2i-payara-micro-promerica
