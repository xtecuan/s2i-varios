#!/bin/bash


docker tag airhackspromerica/s2i-payara-micro-promerica:latest default-route-openshift-image-registry.apps.ocp01.promnet.com.sv/pruebadev/s2i-payara-micro-promerica-new
