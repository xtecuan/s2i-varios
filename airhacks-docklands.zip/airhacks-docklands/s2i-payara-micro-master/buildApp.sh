#!/bin/bash
export KAPP_HOME=$(dirname $(realpath $0))
source ${KAPP_HOME}/environment.sh


if [ -n "$1" ]
then 
	echo "Creating App $1 from WAR using image  ${IMPORTED_IMAGE}"
	oc start-build --from-dir . $1
else
	echo "Usage $0 appname"
fi



