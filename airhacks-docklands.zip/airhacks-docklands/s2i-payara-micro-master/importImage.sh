#!/bin/bash
export KAPP_HOME=$(dirname $(realpath $0))
source ${KAPP_HOME}/environment.sh

oc import-image ${IMPORTED_IMAGE} --from=${PROMERICA_S2I} --confirm





