#!/bin/bash

export IMAGE_RUN="pfc-customer-management-img"
export CONTAINER_NAME="pfc-customer-management"

docker run -d  --name ${CONTAINER_NAME} --env-file environment.txt \
--restart=always \
 --privileged \
-p 8201:8181  ${IMAGE_RUN}
