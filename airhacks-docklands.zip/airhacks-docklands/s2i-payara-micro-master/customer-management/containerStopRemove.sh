#!/bin/bash

export IMAGE_RUN="pfc-customer-management-img"
export CONTAINER_NAME="pfc-customer-management"

docker kill $CONTAINER_NAME
docker rm $CONTAINER_NAME
