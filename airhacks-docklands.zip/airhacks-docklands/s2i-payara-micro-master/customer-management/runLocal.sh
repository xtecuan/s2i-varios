#!/bin/bash

export KAPP_HOME=$(dirname $(realpath $0))

export AS_ADMIN_MASTERPASSWORD=changeit

$KAPP_HOME/mvnw clean install
$KAPP_HOME/mvnw payara-micro:start