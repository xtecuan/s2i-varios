#!/bin/bash

export ALIAS="dev-authorizer-promnet-com-sv"
export PASS=changeit

keytool -importcert -alias ${ALIAS} -file external-cers/${ALIAS}.cer -keystore src/main/resources/MICRO-INF/domain/config/cacerts.jks -storepass ${PASS} -noprompt