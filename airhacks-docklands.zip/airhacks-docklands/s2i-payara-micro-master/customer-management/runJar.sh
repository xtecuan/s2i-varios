#!/bin/bash
export CONTEXT_ROOT=customer-mngmt
export JAR_FILE=/opt/payara/${CONTEXT_ROOT}-microbundle.jar
export HTTP_PROXY=http://10.5.3.200:3128
export HTTPS_PROXY=http://10.5.3.200:3128
export NO_PROXY=localhost,127.0.0.1
export JAVA_OPTS="-Dhttp.proxyHost=10.5.3.200 -Dhttp.proxyPort=3128"
export JAVA_OPTS="$JAVA_OPTS -Dhttps.proxyHost=10.5.3.200 -Dhttps.proxyPort=3128"
export JAVA_OPTS="$JAVA_OPTS -Dhttp.nonProxyHosts=localhost,127.0.0.1"
export JAVA_OPTS="$JAVA_OPTS -Djavax.net.ssl.keyStore=/opt/payara/config/keystore.jks -Djavax.net.ssl.keyStorePassword=changeit"
export JAVA_OPTS="$JAVA_OPTS -Djavax.net.ssl.trustStore=/opt/payara/config/cacerts.jks -Djavax.net.ssl.trustStorePassword=changeit"
export LOGGER_CONF=/opt/payara/config/logger.properties
export HTTP_PORT=9876
export MINTHREADS=10
export MAXTHREADS=100
export HTTPS_PORT=8181
export ALIAS=s1as

#--logproperties $LOGGER_CONF

java -jar $JAVA_OPTS $JAR_FILE  --port $HTTP_PORT \
--minhttpthreads $MINTHREADS --maxhttpthreads $MAXTHREADS --nocluster --sslPort $HTTPS_PORT \
--sslcert $ALIAS --contextroot $CONTEXT_ROOT

