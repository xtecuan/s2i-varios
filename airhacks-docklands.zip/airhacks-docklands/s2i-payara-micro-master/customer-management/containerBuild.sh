#!/bin/bash

export IMAGE_RUN="pfc-customer-management-img"
export CONTAINER_NAME="pfc-customer-management"

docker build . -t ${IMAGE_RUN}