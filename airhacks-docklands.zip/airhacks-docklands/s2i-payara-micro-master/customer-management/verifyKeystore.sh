#!/bin/bash

keytool --list -v -alias s1as -keystore src/main/resources/MICRO-INF/domain/config/keystore.jks -storepass changeit
