/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.promerica.customer.utils;

import com.promerica.customer.model.ErrorBase;
import com.promerica.customer.model.ErrorDetail;
import java.util.HashMap;
import java.util.logging.Level;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

/**
 *
 * @author Miguel Garcia <megarcia@promerica.com.sv>
 */
@Provider
public class CustomInternalException extends RequestScopedService implements ExceptionMapper<Throwable> {

    public CustomInternalException(){}
    
    @Override
    @Produces({MediaType.APPLICATION_JSON})
    public Response toResponse(Throwable e) {
        logger.log(Level.SEVERE,"Error de aplicacion uid {0}", new Object[]{uui});
        logger.log(Level.SEVERE,"Error de aplicacion", e);
        int code = 500;
        ErrorBase errorBase = new ErrorBase();
        if( e instanceof WebApplicationException ){
            errorBase.setCode(String.valueOf(((WebApplicationException) e).getResponse().getStatus()));
            code = ((WebApplicationException) e).getResponse().getStatus();
        }else{
            errorBase.setCode(String.valueOf(code));
        }
        errorBase.setMessage(e.getMessage());
        errorBase.setId(uui);

        ErrorDetail detail = new ErrorDetail();
        detail.setPath("Server");
        detail.setMessage(e.getMessage());
        if( e instanceof WebApplicationException ){
            detail.setErrorCode(String.valueOf(((WebApplicationException) e).getResponse().getStatus()));
        }else{
            detail.setErrorCode(String.valueOf(code));
        }
        detail.setUrl(httpServletRequest.getRequestURI());
        errorBase.getErrors().add(detail);

        return Response.status(code)
                .entity(new HashMap<String, Object>() {
                    {
                        put("Error", errorBase);
                    }
                }
                ).build();
    }

}
