
package com.promerica.customer.model.personalInfo;

import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "country",
    "firstLevel",
    "secondLevel",
    "thirdLevel",
    "fourthLevel",
    "physicalAddress"
})
@Generated("jsonschema2pojo")
public class AddressInformation {

    @Valid
    @NotNull(message = "Debe incluir country.")
    @JsonProperty("country")
    private Country country;
    @Valid
    @NotNull(message = "Debe incluir firsLevel.")
    @JsonProperty("firstLevel")
    private FirstLevel firstLevel;
    @Valid
    @NotNull(message = "Debe incluir secondLevel.")
    @JsonProperty("secondLevel")
    private SecondLevel secondLevel;
    @JsonProperty("thirdLevel")
    private ThirdLevel thirdLevel;
    @JsonProperty("fourthLevel")
    private FourthLevel fourthLevel;
    @Valid
    @NotNull(message = "Debe incluir physicalAddress.")
    @NotBlank(message = "physicalAddress no puede estar en blanco.")
    @JsonProperty("physicalAddress")
    private String physicalAddress;
    
    @JsonProperty("country")
    public Country getCountry() {
        return country;
    }

    @JsonProperty("country")
    public void setCountry(Country country) {
        this.country = country;
    }

    @JsonProperty("firstLevel")
    public FirstLevel getFirstLevel() {
        return firstLevel;
    }

    @JsonProperty("firstLevel")
    public void setFirstLevel(FirstLevel firstLevel) {
        this.firstLevel = firstLevel;
    }

    @JsonProperty("secondLevel")
    public SecondLevel getSecondLevel() {
        return secondLevel;
    }

    @JsonProperty("secondLevel")
    public void setSecondLevel(SecondLevel secondLevel) {
        this.secondLevel = secondLevel;
    }

    @JsonProperty("thirdLevel")
    public ThirdLevel getThirdLevel() {
        return thirdLevel;
    }

    @JsonProperty("thirdLevel")
    public void setThirdLevel(ThirdLevel thirdLevel) {
        this.thirdLevel = thirdLevel;
    }

    @JsonProperty("fourthLevel")
    public FourthLevel getFourthLevel() {
        return fourthLevel;
    }

    @JsonProperty("fourthLevel")
    public void setFourthLevel(FourthLevel fourthLevel) {
        this.fourthLevel = fourthLevel;
    }

    @JsonProperty("physicalAddress")
    public String getPhysicalAddress() {
        return physicalAddress;
    }

    @JsonProperty("physicalAddress")
    public void setPhysicalAddress(String physicalAddress) {
        this.physicalAddress = physicalAddress;
    }


}
