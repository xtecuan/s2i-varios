/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package com.promerica.customer.utils;

import com.promerica.customer.mngmt.EsbSoapClient;
import com.promerica.customer.model.ErrorBase;
import com.promerica.customer.model.ErrorDetail;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Inject;
import javax.ws.rs.core.Context;
import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import org.apache.commons.jxpath.JXPathContext;

/**
 *
 * @author Gabriel Bran <gabriel.bran@promerica.com.sv>
 */
public class RequestScopedService {

    protected ValidatorFactory validatorFactory
            = Validation.buildDefaultValidatorFactory();

    @Inject
    protected EsbSoapClient esbClient;

    @Inject
    protected transient Logger logger;

    @Inject
    protected String uui;

    @Context
    protected HttpServletRequest httpServletRequest;

    @Context
    protected HttpHeaders headers;

    @Context
    UriInfo uriInfo;

    public static final String COUNTRY = "SV";

    public static final Set<String> REQUIRED_HEADERS = new HashSet<String>() {
        {
            add("x-origin-ip-address");
            add("accept-language");
            add("x-subscription-id");
            add("x-user-code");
            add("x-origin-country");
            add("x-user-code");
        }
    };

    protected <T> void validateModel(T model) throws BaseException {

        Validator validator = validatorFactory.getValidator();
        Set<ConstraintViolation<T>> errors = validator.validate(model);

        if (!errors.isEmpty()) {

            ErrorBase errorBase = new ErrorBase();
            errorBase.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            errorBase.setMessage(Constants.VALIDATION_ERROR_MESSAGE_JSON_REQUEST);
            errorBase.setId(uui);

            for (ConstraintViolation<T> error : errors) {
                ErrorDetail detail = new ErrorDetail();
                detail.setPath(error.getRootBeanClass().getName() + "." + error.getPropertyPath());
                detail.setMessage(error.getMessage());
                detail.setErrorCode(Constants.VALIDATION_ERROR_CODE_JSON_REQUEST);
                detail.setUrl(httpServletRequest.getRequestURI());
                errorBase.getErrors().add(detail);
            }

            // TODO: log with error id.
            throw new BaseException(errorBase);
        }
    }

    protected void validateHeaders() throws BaseException {
        ErrorBase errorBase = new ErrorBase();
        errorBase.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
        errorBase.setMessage(Constants.VALIDATION_ERROR_MESSAGE_HEADERS_REQUEST);
        errorBase.setId(uui);

        for (String header : REQUIRED_HEADERS) {
            if (!headers.getRequestHeaders().containsKey(header)) {
                ErrorDetail detail = new ErrorDetail();
                detail.setPath("Request.Header");
                detail.setMessage(header + " No encontrado");
                detail.setErrorCode(Constants.VALIDATION_ERROR_CODE_HEADERS_REQUEST);
                detail.setUrl(httpServletRequest.getRequestURI());
                errorBase.getErrors().add(detail);
            }
        }

        if (!errorBase.getErrors().isEmpty()) {
            throw new BaseException(errorBase);
        }
    }

    protected void validateSpiResponse(com.promerica.spi.client.core.Response esbResponse) throws BaseException, NoDataFoundException {

        ErrorBase errorBase = new ErrorBase();
        errorBase.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
        errorBase.setMessage(Constants.VALIDATION_ERROR_MESSAGE_NO_DATA_FOUND);
        errorBase.setId(uui);

        JXPathContext jXPathContext = contextFrom(esbResponse);

        String pcodRespuesta = (String) jXPathContext.getValue(
                "entity[name='transactionResult']/attributes[translate(name,'ABCDEFGHIJKLMNOPURSTUWXYZ','abcdefghijklmnopurstuwxyz')='pcodrespuesta']/value");
        String pmensajeusuario = (String) jXPathContext.getValue(
                "entity[name='transactionResult']/attributes[translate(name,'ABCDEFGHIJKLMNOPURSTUWXYZ','abcdefghijklmnopurstuwxyz')='pmensajeusuario']/value");
        String pmensajetecnico = (String) jXPathContext.getValue(
                "entity[name='transactionResult']/attributes[translate(name,'ABCDEFGHIJKLMNOPURSTUWXYZ','abcdefghijklmnopurstuwxyz')='pmensajetecnico']/value");

        ErrorDetail detail = new ErrorDetail();

        detail.setPath("SPI");
        detail.setUrl(httpServletRequest.getRequestURI());

        if (pcodRespuesta != null && !"".equals(pcodRespuesta)) {
            detail.setErrorCode(pcodRespuesta);
            logger.log(Level.WARNING, "Error en servicio SPI uid: {0} pcodrespuesta: {1} - pmensajetecnico:{2} - pmensajeusuario:{3}", new Object[]{uui, pcodRespuesta, pmensajetecnico, pmensajeusuario});
            detail.setMessage(pmensajeusuario);
            errorBase.getErrors().add(detail);
        } else if (!esbResponse.getCollections().isEmpty() && esbResponse.getCollections().get(0).getEntities().isEmpty()) {
            errorBase.setCode(Response.Status.NOT_FOUND.toString());
            detail.setErrorCode(Constants.VALIDATION_ERROR_CODE_NO_DATA_FOUND);
            detail.setMessage(Constants.VALIDATION_ERROR_MESSAGE_NO_DATA_FOUND);
            errorBase.getErrors().add(detail);
            throw new NoDataFoundException(errorBase);
        }

        if (!errorBase.getErrors().isEmpty()) {
            throw new BaseException(errorBase);
        }
    }

    protected <T> JXPathContext contextFrom(T entity) {
        JXPathContext jXPathContext = JXPathContext.newContext(entity);
        jXPathContext.setLenient(true);
        return jXPathContext;
    }

    protected Response.ResponseBuilder defaultResponse(Response.ResponseBuilder response, long timemilis) {
        response.header("X-Response-Time", timemilis);
        response.header("X-Origin-Country", COUNTRY);
        response.header("X-Response-Url", httpServletRequest.getRequestURI());
        response.header("X-Response-IP-Address", uriInfo.getBaseUri().getHost());
        try {
            response.header("X-Response-MachineName", InetAddress.getLocalHost().getHostName());
        } catch (UnknownHostException ex) {
            logger.log(Level.WARNING, "No se pudo obtener hostname para header X-Response-MachineName...", ex);
            response.header("X-Response-MachineName", "");
        }
        return response;
    }

}
