/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.promerica.customer.utils;

import java.util.HashMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

/**
 *
 * @author Gabriel Bran <gabriel.bran@promerica.com.sv>
 */
@Provider
public class BaseExceptionMapper extends RequestScopedService
        implements ExceptionMapper<BaseException> {

    @Override
    public Response toResponse(BaseException e) {

        return Response.status(Response.Status.BAD_REQUEST)
                .entity(new HashMap<String, Object>() {
                    {
                        put("Error", e.getError());
                    }
                }
                ).build();
    }

}
