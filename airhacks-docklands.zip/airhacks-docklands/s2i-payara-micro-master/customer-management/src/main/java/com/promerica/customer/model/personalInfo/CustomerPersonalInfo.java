
package com.promerica.customer.model.personalInfo;

import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import javax.json.bind.annotation.JsonbPropertyOrder;
import javax.json.bind.annotation.JsonbProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "Data"
})
@Generated("jsonschema2pojo")
public class CustomerPersonalInfo {

    @JsonbProperty("Data")
    private Data data;
    @JsonIgnore

    @JsonbProperty("Data")
    public Data getData() {
        return data;
    }

    @JsonbProperty("Data")
    public void setData(Data data) {
        this.data = data;
    }

    

}
