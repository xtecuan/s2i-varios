/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.promerica.customer.model;

import java.io.Serializable;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author Gabriel Bran <gabriel.bran@promerica.com.sv>
 */
@XmlRootElement(name = "identityDocument")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "identityDocument", namespace = "http://promerica.com.sv/schema/onboarding", propOrder = {
    "number", "type"
})
public class IdentityDocument implements Serializable {

    @XmlAttribute
    @NotNull(message = "Numero de documento es requerido.")
    private String number;
    @XmlAttribute
    @NotNull(message = "Tipo de documento es requerido.")
    private DocumentType type;

    public IdentityDocument() {
    }

    public IdentityDocument(String number, DocumentType type) {
        this.number = number;
        this.type = type;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public DocumentType getType() {
        return type;
    }

    public void setType(DocumentType type) {
        this.type = type;
    }

}
