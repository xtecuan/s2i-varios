/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.promerica.customer.model;

import java.io.Serializable;
import javax.json.bind.annotation.JsonbPropertyOrder;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author Gabriel Bran <gabriel.bran@promerica.com.sv>
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Error", namespace = "http://promerica.com.sv/schema/onboarding", propOrder = {
    "path", "message", "errorCode", "url"
})
@JsonbPropertyOrder({
    "path",
    "message",
    "errorCode",
    "url"
})
public class ErrorDetail implements Serializable {

    private String path;
    private String message;
    private String errorCode;
    private String url;

    public ErrorDetail() {
    }

    public ErrorDetail(String path, String message, String errorCode, String url) {
        this.path = path;
        this.message = message;
        this.errorCode = errorCode;
        this.url = url;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

}
