/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package com.promerica.customer.utils;

import com.promerica.customer.model.ErrorBase;

/**
 *
 * @author Gabriel Bran <gabriel.bran@promerica.com.sv>
 */
public class BaseException extends Exception {

    private ErrorBase error;

    /**
     * Creates a new instance of <code>BaseException</code> without detail
     * message.
     */
    public BaseException() {
    }

    /**
     * Constructs an instance of <code>BaseException</code> with the specified
     * detail message.
     *
     * @param msg the detail message.
     */
    public BaseException(String msg) {
        super(msg);
    }

    /**
     * Constructs an instance of <code>BaseException</code> with the specified
     * detail error.
     *
     * @param error the detail message.
     */
    public BaseException(ErrorBase error) {
        this.error = error;
    }

    public ErrorBase getError() {
        return error;
    }

}
