package com.promerica.spi.client.core;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Clase Java para resolve complex type.
 *
 * <p>
 * El siguiente fragmento de esquema especifica el contenido que se espera que
 * haya en esta clase.
 *
 * <pre>
 * &lt;complexType name="resolve">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="request" type="{http://promerica.com.sv/ns/spi}request" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "resolve", namespace = "http://expose.services.promerica.com/", propOrder = {
    "request"
})
@XmlRootElement(name = "resolve", namespace = "http://expose.services.promerica.com/")
public class Resolve implements Serializable {

    private final static long serialVersionUID = 1L;

    protected Request request;

    /**
     * Obtiene el valor de la propiedad request.
     *
     * @return possible object is {@link Request }
     *
     */
    public Request getRequest() {
        return request;
    }

    /**
     * Define el valor de la propiedad request.
     *
     * @param value allowed object is {@link Request }
     *
     */
    public void setRequest(Request value) {
        this.request = value;
    }

}
