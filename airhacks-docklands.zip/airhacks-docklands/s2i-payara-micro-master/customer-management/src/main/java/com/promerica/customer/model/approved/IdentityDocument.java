
package com.promerica.customer.model.approved;

import java.io.Serializable;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "number",
    "type"
})
@Generated("jsonschema2pojo")
public class IdentityDocument implements Serializable
{
    @NotNull( message = "Ingrese numero.")
    @NotBlank( message = "Numero no puede encontrarse en blanco.")
    @JsonProperty("number")
    private String number;
    @NotNull( message = "Type es requerido")
    @JsonProperty("type")
    private Type type;
    private final static long serialVersionUID = -3297141248357980994L;

    /**
     * No args constructor for use in serialization
     * 
     */
    public IdentityDocument() {
    }

    /**
     * 
     * @param number
     * @param type
     */
    public IdentityDocument(String number, Type type) {
        super();
        this.number = number;
        this.type = type;
    }

    @JsonProperty("number")
    public String getNumber() {
        return number;
    }

    @JsonProperty("number")
    public void setNumber(String number) {
        this.number = number;
    }

    @JsonProperty("type")
    public Type getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(Type type) {
        this.type = type;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(IdentityDocument.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("number");
        sb.append('=');
        sb.append(((this.number == null)?"<null>":this.number));
        sb.append(',');
        sb.append("type");
        sb.append('=');
        sb.append(((this.type == null)?"<null>":this.type));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.type == null)? 0 :this.type.hashCode()));
        result = ((result* 31)+((this.number == null)? 0 :this.number.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof IdentityDocument) == false) {
            return false;
        }
        IdentityDocument rhs = ((IdentityDocument) other);
        return (((this.type == rhs.type)||((this.type!= null)&&this.type.equals(rhs.type)))&&((this.number == rhs.number)||((this.number!= null)&&this.number.equals(rhs.number))));
    }

}
