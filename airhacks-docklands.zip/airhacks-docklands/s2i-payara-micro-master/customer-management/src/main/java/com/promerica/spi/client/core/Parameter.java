package com.promerica.spi.client.core;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;

/**
 * <p>
 * Clase Java para parameter complex type.
 *
 * <p>
 * El siguiente fragmento de esquema especifica el contenido que se espera que
 * haya en esta clase.
 *
 * <pre>
 * &lt;complexType name="parameter">
 *   &lt;simpleContent>
 *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>string">
 *       &lt;attribute name="name" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="type" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="mode" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="mask" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="index" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="sensitive" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="loggable" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *     &lt;/extension>
 *   &lt;/simpleContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "parameter", propOrder = {
    "value"
})
public class Parameter implements Serializable {

    private final static long serialVersionUID = 1L;

    @XmlValue
    protected String value;
    @XmlAttribute(name = "name", required = true)
    protected String name;
    @XmlAttribute(name = "type", required = true)
    protected String type;
    @XmlAttribute(name = "mode")
    protected String mode;
    @XmlAttribute(name = "mask")
    protected String mask;
    @XmlAttribute(name = "index")
    protected Integer index;
    @XmlAttribute(name = "sensitive")
    protected Boolean sensitive;
    @XmlAttribute(name = "loggable")
    protected Boolean loggable;

    public Parameter() {
    }

    public Parameter(String value, String name, String type, Integer index) {
        this.value = value;
        this.name = name;
        this.type = type;
        this.index = index;
    }

    public Parameter(String value, String name, String type, Integer index, Boolean sensitive, Boolean loggable) {
        this.value = value;
        this.name = name;
        this.type = type;
        this.index = index;
        this.sensitive = sensitive;
        this.loggable = loggable;
    }

    public Parameter(String value, String name, String type, String mode, String mask, Integer index, Boolean sensitive, Boolean loggable) {
        this.value = value;
        this.name = name;
        this.type = type;
        this.mode = mode;
        this.mask = mask;
        this.index = index;
        this.sensitive = sensitive;
        this.loggable = loggable;
    }

    /**
     * Obtiene el valor de la propiedad value.
     *
     * @return possible object is {@link String }
     *
     */
    public String getValue() {
        return value;
    }

    /**
     * Define el valor de la propiedad value.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Obtiene el valor de la propiedad name.
     *
     * @return possible object is {@link String }
     *
     */
    public String getName() {
        return name;
    }

    /**
     * Define el valor de la propiedad name.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Obtiene el valor de la propiedad type.
     *
     * @return possible object is {@link String }
     *
     */
    public String getType() {
        return type;
    }

    /**
     * Define el valor de la propiedad type.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Obtiene el valor de la propiedad mode.
     *
     * @return possible object is {@link String }
     *
     */
    public String getMode() {
        return mode;
    }

    /**
     * Define el valor de la propiedad mode.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setMode(String value) {
        this.mode = value;
    }

    /**
     * Obtiene el valor de la propiedad mask.
     *
     * @return possible object is {@link String }
     *
     */
    public String getMask() {
        return mask;
    }

    /**
     * Define el valor de la propiedad mask.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setMask(String value) {
        this.mask = value;
    }

    /**
     * Obtiene el valor de la propiedad index.
     *
     * @return possible object is {@link Integer }
     *
     */
    public Integer getIndex() {
        return index;
    }

    /**
     * Define el valor de la propiedad index.
     *
     * @param value allowed object is {@link Integer }
     *
     */
    public void setIndex(Integer value) {
        this.index = value;
    }

    /**
     * Obtiene el valor de la propiedad sensitive.
     *
     * @return possible object is {@link Boolean }
     *
     */
    public Boolean isSensitive() {
        return sensitive;
    }

    /**
     * Define el valor de la propiedad sensitive.
     *
     * @param value allowed object is {@link Boolean }
     *
     */
    public void setSensitive(Boolean value) {
        this.sensitive = value;
    }

    /**
     * Obtiene el valor de la propiedad loggable.
     *
     * @return possible object is {@link Boolean }
     *
     */
    public Boolean isLoggable() {
        return loggable;
    }

    /**
     * Define el valor de la propiedad loggable.
     *
     * @param value allowed object is {@link Boolean }
     *
     */
    public void setLoggable(Boolean value) {
        this.loggable = value;
    }

}
