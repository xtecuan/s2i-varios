
package com.promerica.customer.model.approved;

import java.io.Serializable;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import javax.json.bind.annotation.JsonbPropertyOrder;
import javax.json.bind.annotation.JsonbProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "Data"
})
@Generated("jsonschema2pojo")
public class GetCustomerHasPreapprovedProducts implements Serializable
{

    @JsonbProperty("Data")
    private Data data;
    private final static long serialVersionUID = -5966651307677440485L;

    /**
     * No args constructor for use in serialization
     * 
     */
    public GetCustomerHasPreapprovedProducts() {
    }

    /**
     * 
     * @param data
     */
    public GetCustomerHasPreapprovedProducts(Data data) {
        super();
        this.data = data;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(GetCustomerHasPreapprovedProducts.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("data");
        sb.append('=');
        sb.append(((this.data == null)?"<null>":this.data));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.data == null)? 0 :this.data.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof GetCustomerHasPreapprovedProducts) == false) {
            return false;
        }
        GetCustomerHasPreapprovedProducts rhs = ((GetCustomerHasPreapprovedProducts) other);
        return ((this.data == rhs.data)||((this.data!= null)&&this.data.equals(rhs.data)));
    }

}
