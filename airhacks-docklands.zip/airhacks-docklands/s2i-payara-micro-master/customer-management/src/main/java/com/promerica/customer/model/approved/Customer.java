
package com.promerica.customer.model.approved;

import java.io.Serializable;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "hasPreApprovedProducts"
})
@Generated("jsonschema2pojo")
public class Customer implements Serializable
{

    @JsonProperty("hasPreApprovedProducts")
    private Boolean hasPreApprovedProducts;
    private final static long serialVersionUID = -2533882661795190691L;

    /**
     * No args constructor for use in serialization
     * 
     */
    public Customer() {
    }

    /**
     * 
     * @param hasPreApprovedProducts
     */
    public Customer(Boolean hasPreApprovedProducts) {
        super();
        this.hasPreApprovedProducts = hasPreApprovedProducts;
    }

    @JsonProperty("hasPreApprovedProducts")
    public Boolean getHasPreApprovedProducts() {
        return hasPreApprovedProducts;
    }

    @JsonProperty("hasPreApprovedProducts")
    public void setHasPreApprovedProducts(Boolean hasPreApprovedProducts) {
        this.hasPreApprovedProducts = hasPreApprovedProducts;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Customer.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("hasPreApprovedProducts");
        sb.append('=');
        sb.append(((this.hasPreApprovedProducts == null)?"<null>":this.hasPreApprovedProducts));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.hasPreApprovedProducts == null)? 0 :this.hasPreApprovedProducts.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Customer) == false) {
            return false;
        }
        Customer rhs = ((Customer) other);
        return ((this.hasPreApprovedProducts == rhs.hasPreApprovedProducts)||((this.hasPreApprovedProducts!= null)&&this.hasPreApprovedProducts.equals(rhs.hasPreApprovedProducts)));
    }

}
