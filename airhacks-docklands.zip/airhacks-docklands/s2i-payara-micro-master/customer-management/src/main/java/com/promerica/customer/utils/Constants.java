/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.promerica.customer.utils;

/**
 *
 * @author Miguel Garcia <megarcia@promerica.com.sv>
 */
public class Constants {
    
    
    public static final String VALIDATION_ERROR_CODE_JSON_REQUEST = "000001";
    public static final String VALIDATION_ERROR_CODE_HEADERS_REQUEST = "000002";
    public static final String VALIDATION_ERROR_CODE_ESB_CORE = "000003";
    public static final String VALIDATION_ERROR_CODE_NO_DATA_FOUND = "000004";
    
    public static final String VALIDATION_ERROR_MESSAGE_JSON_REQUEST = "Error en request/estructura de json.";
    public static final String VALIDATION_ERROR_MESSAGE_HEADERS_REQUEST = "Error en requests/headers de peticion.";
    public static final String VALIDATION_ERROR_MESSAGE_ESB_CORE = "Error de respuesta de Bus de servicios.";
    public static final String VALIDATION_ERROR_MESSAGE_NO_DATA_FOUND = "La consulta no retorna datos.";
    
}
