
package com.promerica.customer.model.disclaimer;

import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;
import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;
import java.util.Date;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "customer",
    "contractType"
})
@Generated("jsonschema2pojo")
@Entity("contrato-preaprobada-disclaimers")
public class CustomerDisclaimer {
    @Id
    private String id;
    @Valid
    @NotNull(message = "Debe incluir customer.")
    @JsonProperty("customer")
    private Customer customer;
    @Valid
    @NotNull(message = "Debe incluir contractType.")
    @JsonProperty("contractType")
    private ContractType contractType;
    @JsonProperty("responseDisclaimer")
    private ResponseDisclaimer responseDisclaimer;
    private Date date;
    
    @JsonProperty("customer")
    public Customer getCustomer() {
        return customer;
    }

    @JsonProperty("customer")
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @JsonProperty("contractType")
    public ContractType getContractType() {
        return contractType;
    }

    @JsonProperty("contractType")
    public void setContractType(ContractType contractType) {
        this.contractType = contractType;
    }

    public ResponseDisclaimer getResponseDisclaimer() {
        return responseDisclaimer;
    }

    public void setResponseDisclaimer(ResponseDisclaimer responseDisclaimer) {
        this.responseDisclaimer = responseDisclaimer;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
    
}
