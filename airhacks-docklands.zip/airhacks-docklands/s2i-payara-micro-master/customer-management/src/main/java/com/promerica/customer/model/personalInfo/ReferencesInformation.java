
package com.promerica.customer.model.personalInfo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "identityDocument",
    "name",
    "relationshipCode",
    "phoneNumbers"
})
@Generated("jsonschema2pojo")
public class ReferencesInformation {

    @JsonProperty("identityDocument")
    private IdentityDocument identityDocument;
    @JsonProperty("name")
    private String name;
    @JsonProperty("relationshipCode")
    private String relationshipCode;
    @JsonProperty("phoneNumbers")
    private List<String> phoneNumbers = null;
    @JsonIgnore
    

    @JsonProperty("identityDocument")
    public IdentityDocument getIdentityDocument() {
        return identityDocument;
    }

    @JsonProperty("identityDocument")
    public void setIdentityDocument(IdentityDocument identityDocument) {
        this.identityDocument = identityDocument;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("relationshipCode")
    public String getRelationshipCode() {
        return relationshipCode;
    }

    @JsonProperty("relationshipCode")
    public void setRelationshipCode(String relationshipCode) {
        this.relationshipCode = relationshipCode;
    }

    @JsonProperty("phoneNumbers")
    public List<String> getPhoneNumbers() {
        return phoneNumbers;
    }

    @JsonProperty("phoneNumbers")
    public void setPhoneNumbers(List<String> phoneNumbers) {
        this.phoneNumbers = phoneNumbers;
    }

}
