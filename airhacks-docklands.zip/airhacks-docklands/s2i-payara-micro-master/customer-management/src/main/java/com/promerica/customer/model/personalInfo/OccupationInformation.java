
package com.promerica.customer.model.personalInfo;

import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "code",
    "startDate",
    "incomeType",
    "salary",
    "currency",
    "contactInformation",
    "addressInformation"
})
@Generated("jsonschema2pojo")
public class OccupationInformation {

    @JsonProperty("code")
    private String code;
    @JsonProperty("startDate")
    private String startDate;
    @JsonProperty("incomeType")
    private String incomeType;
    @JsonProperty("salary")
    private Integer salary;
    @JsonProperty("currency")
    private Currency currency;
    @JsonProperty("contactInformation")
    private ContactInformation contactInformation;
    @Valid
    @NotNull
    @JsonProperty("addressInformation")
    private AddressInformation addressInformation;
    @JsonIgnore
    

    @JsonProperty("code")
    public String getCode() {
        return code;
    }

    @JsonProperty("code")
    public void setCode(String code) {
        this.code = code;
    }

    @JsonProperty("startDate")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("startDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    @JsonProperty("incomeType")
    public String getIncomeType() {
        return incomeType;
    }

    @JsonProperty("incomeType")
    public void setIncomeType(String incomeType) {
        this.incomeType = incomeType;
    }

    @JsonProperty("salary")
    public Integer getSalary() {
        return salary;
    }

    @JsonProperty("salary")
    public void setSalary(Integer salary) {
        this.salary = salary;
    }

    @JsonProperty("currency")
    public Currency getCurrency() {
        return currency;
    }

    @JsonProperty("currency")
    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    @JsonProperty("contactInformation")
    public ContactInformation getContactInformation() {
        return contactInformation;
    }

    @JsonProperty("contactInformation")
    public void setContactInformation(ContactInformation contactInformation) {
        this.contactInformation = contactInformation;
    }

    @JsonProperty("addressInformation")
    public AddressInformation getAddressInformation() {
        return addressInformation;
    }

    @JsonProperty("addressInformation")
    public void setAddressInformation(AddressInformation addressInformation) {
        this.addressInformation = addressInformation;
    }

}
