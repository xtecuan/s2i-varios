@javax.xml.bind.annotation.XmlSchema(namespace = "http://promerica.com.sv/ns/spi")
package com.promerica.spi.client.core;
