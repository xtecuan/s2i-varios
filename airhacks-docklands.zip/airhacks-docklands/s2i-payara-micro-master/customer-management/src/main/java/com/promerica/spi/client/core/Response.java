package com.promerica.spi.client.core;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Clase Java para response complex type.
 *
 * <p>
 * El siguiente fragmento de esquema especifica el contenido que se espera que
 * haya en esta clase.
 *
 * <pre>
 * &lt;complexType name="response">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="entity" type="{http://promerica.com.sv/ns/spi}entity" minOccurs="0"/>
 *         &lt;element name="collection" type="{http://promerica.com.sv/ns/spi}collection" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="exception-message" type="{http://promerica.com.sv/ns/spi}exception-message" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="uid" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="correlation-id" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "response", propOrder = {
    "entity",
    "collections",
    "exceptionMessage"
})
@XmlRootElement(name = "response")
public class Response implements Serializable {

    private final static long serialVersionUID = 1L;

    protected Entity entity;
    @XmlElement(name = "collection")
    protected List<Collection> collections;
    @XmlElement(name = "exception-message")
    protected ExceptionMessage exceptionMessage;
    @XmlAttribute(name = "uid", required = true)
    protected String uid;
    @XmlAttribute(name = "correlation-id")
    protected String correlationId;

    /**
     * Obtiene el valor de la propiedad entity.
     *
     * @return possible object is {@link Entity }
     *
     */
    public Entity getEntity() {
        return entity;
    }

    /**
     * Define el valor de la propiedad entity.
     *
     * @param value allowed object is {@link Entity }
     *
     */
    public void setEntity(Entity value) {
        this.entity = value;
    }

    /**
     * Gets the value of the collections property.
     *
     * <p>
     * This accessor method returns a reference to the live list, not a
     * snapshot. Therefore any modification you make to the returned list will
     * be present inside the JAXB object. This is why there is not a
     * <CODE>set</CODE> method for the collections property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCollections().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Collection }
     *
     *
     * @return
     */
    public List<Collection> getCollections() {
        if (collections == null) {
            collections = new ArrayList<>();
        }
        return this.collections;
    }

    /**
     * Obtiene el valor de la propiedad exceptionMessage.
     *
     * @return possible object is {@link ExceptionMessage }
     *
     */
    public ExceptionMessage getExceptionMessage() {
        return exceptionMessage;
    }

    /**
     * Define el valor de la propiedad exceptionMessage.
     *
     * @param value allowed object is {@link ExceptionMessage }
     *
     */
    public void setExceptionMessage(ExceptionMessage value) {
        this.exceptionMessage = value;
    }

    /**
     * Obtiene el valor de la propiedad uid.
     *
     * @return possible object is {@link String }
     *
     */
    public String getUid() {
        return uid;
    }

    /**
     * Define el valor de la propiedad uid.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setUid(String value) {
        this.uid = value;
    }

    /**
     * Obtiene el valor de la propiedad correlationId.
     *
     * @return possible object is {@link String }
     *
     */
    public String getCorrelationId() {
        return correlationId;
    }

    /**
     * Define el valor de la propiedad correlationId.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setCorrelationId(String value) {
        this.correlationId = value;
    }

}
