package com.promerica.spi.client.core;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Clase Java para resolveResponse complex type.
 *
 * <p>
 * El siguiente fragmento de esquema especifica el contenido que se espera que
 * haya en esta clase.
 *
 * <pre>
 * &lt;complexType name="resolveResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="return" type="{http://promerica.com.sv/ns/spi}response" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "resolveResponse", namespace = "http://expose.services.promerica.com/", propOrder = {
    "_return"
})
@XmlRootElement(name = "resolveResponse", namespace = "http://expose.services.promerica.com/")
public class ResolveResponse implements Serializable {

    private final static long serialVersionUID = 1L;

    @XmlElement(name = "return")
    protected Response _return;

    /**
     * Obtiene el valor de la propiedad return.
     *
     * @return possible object is {@link Response }
     *
     */
    public Response getReturn() {
        return _return;
    }

    /**
     * Define el valor de la propiedad return.
     *
     * @param value allowed object is {@link Response }
     *
     */
    public void setReturn(Response value) {
        this._return = value;
    }

}
