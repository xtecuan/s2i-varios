/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.promerica.customer.model;

import java.util.ArrayList;
import java.util.List;
import javax.json.bind.annotation.JsonbPropertyOrder;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author Gabriel Bran <gabriel.bran@promerica.com.sv>
 */
@XmlRootElement(name = "Error")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Error", namespace = "http://promerica.com.sv/schema/onboarding", propOrder = {
    "code", "message", "id", "errors"
})
@JsonbPropertyOrder({
    "code",
    "message",
    "id",
    "errors"
})
public class ErrorBase {

    private String code;
    private String message;
    private String id;
    private List<ErrorDetail> errors;

    public ErrorBase() {
        this.errors = new ArrayList<>();
    }

    public ErrorBase(String code, String message, String id, List<ErrorDetail> errors) {
        this.code = code;
        this.message = message;
        this.id = id;
        this.errors = errors;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<ErrorDetail> getErrors() {
        return errors;
    }

    public void setErrors(List<ErrorDetail> errors) {
        this.errors = errors;
    }

}
