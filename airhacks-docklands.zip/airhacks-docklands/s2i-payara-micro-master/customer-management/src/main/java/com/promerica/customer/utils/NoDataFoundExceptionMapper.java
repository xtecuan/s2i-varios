/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.promerica.customer.utils;

import java.util.HashMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

/**
 *
 * @author Miguel Garcia <megarcia@promerica.com.sv>
 */
@Provider
public class NoDataFoundExceptionMapper extends RequestScopedService implements ExceptionMapper<NoDataFoundException>{
    @Override
    public Response toResponse(NoDataFoundException e) {

        return Response.status(Response.Status.NOT_FOUND)
                .entity(new HashMap<String, Object>() {
                    {
                        put("Error", e.getError());
                    }
                }
                ).build();
    }
}
