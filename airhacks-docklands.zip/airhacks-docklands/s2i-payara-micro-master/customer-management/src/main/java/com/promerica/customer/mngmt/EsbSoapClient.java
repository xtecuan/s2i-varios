/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.promerica.customer.mngmt;

import com.promerica.spi.client.core.Request;
import com.promerica.spi.client.core.Response;
import com.promerica.spi.client.core.SoapExposer;
import com.promerica.spi.client.core.SoapExposerService;
import com.sun.xml.ws.client.BindingProviderProperties;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.xml.ws.BindingProvider;
import org.eclipse.microprofile.config.inject.ConfigProperty;

/**
 *
 * @author Gabriel Bran <gabriel.bran@promerica.com.sv>
 */
@Dependent
public class EsbSoapClient {

    @Inject
    private transient Logger logger;
    private SoapExposer endpoint;
    private SoapExposerService service;
    
    @Inject
    @ConfigProperty(name = "esb.url", defaultValue = "defaultValue")
    private String esbUrlProp;

    @PostConstruct
    public void init() {
        try {
            this.service = new SoapExposerService(
                    new URL(esbUrlProp));
            this.endpoint = service.getSoapExposerPort();

            // TODO: set ESB request timeouts.
            ((BindingProvider) this.endpoint).getRequestContext().put(BindingProviderProperties.CONNECT_TIMEOUT, 3);
            //((BindingProvider) this.endpoint).getRequestContext().put("com.sun.xml.ws.connect.timeout", 300);
            //((BindingProvider) this.endpoint).getRequestContext().put("com.sun.xml.ws.request.timeout", 60000);
        } catch (MalformedURLException e) {
            logger.log(Level.SEVERE, ">> error al invocar servicio ESB: ", e);
        }
    }

    public Response resolve(Request request){

        // TODO: handle connection timeout exception.

        return endpoint.resolve(request);
    }
}
