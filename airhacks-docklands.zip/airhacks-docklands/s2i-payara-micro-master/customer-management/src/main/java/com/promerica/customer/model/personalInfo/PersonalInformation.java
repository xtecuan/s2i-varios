
package com.promerica.customer.model.personalInfo;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "identityDocument",
    "firstName",
    "secondName",
    "firstSurname",
    "secondSurname",
    "marriedSurname",
    "gender",
    "birthdate",
    "maritalStatus",
    "nationality",
    "taxIdentityNumber"
})
@Generated("jsonschema2pojo")
public class PersonalInformation {
    @Valid
    @NotNull(message = "Debe incluir identityDocument.")
    @JsonProperty("identityDocument")
    private IdentityDocument identityDocument;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("secondName")
    private String secondName;
    @JsonProperty("firstSurname")
    private String firstSurname;
    @JsonProperty("secondSurname")
    private String secondSurname;
    @JsonProperty("marriedSurname")
    private String marriedSurname;
    @JsonProperty("gender")
    private String gender;
    @JsonProperty("birthdate")
    private String birthdate;
    @JsonProperty("maritalStatus")
    private String maritalStatus;
    @JsonProperty("nationality")
    private String nationality;
    @Valid
    @NotNull( message = "Debe incluir taxIdentityNumber.")
    @NotBlank( message = "taxIdentityNumber no puede estar en blanco.")
    @JsonProperty("taxIdentityNumber")
    private String taxIdentityNumber;
    @JsonIgnore
    

    @JsonProperty("identityDocument")
    public IdentityDocument getIdentityDocument() {
        return identityDocument;
    }

    @JsonProperty("identityDocument")
    public void setIdentityDocument(IdentityDocument identityDocument) {
        this.identityDocument = identityDocument;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @JsonProperty("secondName")
    public String getSecondName() {
        return secondName;
    }

    @JsonProperty("secondName")
    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    @JsonProperty("firstSurname")
    public String getFirstSurname() {
        return firstSurname;
    }

    @JsonProperty("firstSurname")
    public void setFirstSurname(String firstSurname) {
        this.firstSurname = firstSurname;
    }

    @JsonProperty("secondSurname")
    public String getSecondSurname() {
        return secondSurname;
    }

    @JsonProperty("secondSurname")
    public void setSecondSurname(String secondSurname) {
        this.secondSurname = secondSurname;
    }

    @JsonProperty("marriedSurname")
    public String getMarriedSurname() {
        return marriedSurname;
    }

    @JsonProperty("marriedSurname")
    public void setMarriedSurname(String marriedSurname) {
        this.marriedSurname = marriedSurname;
    }

    @JsonProperty("gender")
    public String getGender() {
        return gender;
    }

    @JsonProperty("gender")
    public void setGender(String gender) {
        this.gender = gender;
    }

    @JsonProperty("birthdate")
    public String getBirthdate() {
        return birthdate;
    }

    @JsonProperty("birthdate")
    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    @JsonProperty("maritalStatus")
    public String getMaritalStatus() {
        return maritalStatus;
    }

    @JsonProperty("maritalStatus")
    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    @JsonProperty("nationality")
    public String getNationality() {
        return nationality;
    }

    @JsonProperty("nationality")
    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    @JsonProperty("taxIdentityNumber")
    public String getTaxIdentityNumber() {
        return taxIdentityNumber;
    }

    @JsonProperty("taxIdentityNumber")
    public void setTaxIdentityNumber(String taxIdentityNumber) {
        this.taxIdentityNumber = taxIdentityNumber;
    }

}
