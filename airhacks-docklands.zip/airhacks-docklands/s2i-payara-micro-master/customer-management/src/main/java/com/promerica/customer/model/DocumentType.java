/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.promerica.customer.model;

import java.io.Serializable;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author Gabriel Bran <gabriel.bran@promerica.com.sv>
 */
@XmlRootElement(name = "documenType")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "documenType", namespace = "http://promerica.com.sv/schema/onboarding", propOrder = {
    "code", "name"
})
public class DocumentType implements Serializable {

    @XmlAttribute
    @NotNull(message = "Codigo de tipo de documento es requerido.")
    private String code;
    @XmlAttribute
    private String name;

    public DocumentType() {
    }

    public DocumentType(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
