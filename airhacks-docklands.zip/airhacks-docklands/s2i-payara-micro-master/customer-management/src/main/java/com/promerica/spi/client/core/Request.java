package com.promerica.spi.client.core;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * <p>
 * Clase Java para request complex type.
 *
 * <p>
 * El siguiente fragmento de esquema especifica el contenido que se espera que
 * haya en esta clase.
 *
 * <pre>
 * &lt;complexType name="request">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="parameter" type="{http://promerica.com.sv/ns/spi}parameter" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="service" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="service-version" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="application" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="user" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="operation" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="uid" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="token" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="uid-origin" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="date-request" type="{http://www.w3.org/2001/XMLSchema}dateTime" />
 *       &lt;attribute name="async" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="eis-uuid" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="timeout" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "request", propOrder = {
    "parameters"
})
@XmlRootElement(name = "request")
public class Request implements Serializable {

    private final static long serialVersionUID = 1L;

    @XmlElement(name = "parameter", nillable = true)
    protected List<Parameter> parameters;
    @XmlAttribute(name = "service", required = true)
    protected String service;
    @XmlAttribute(name = "service-version", required = true)
    protected String serviceVersion;
    @XmlAttribute(name = "application", required = true)
    protected String application;
    @XmlAttribute(name = "user", required = true)
    protected String user;
    @XmlAttribute(name = "operation", required = true)
    protected String operation;
    @XmlAttribute(name = "uid")
    protected String uid;
    @XmlAttribute(name = "token")
    protected String token;
    @XmlAttribute(name = "uid-origin")
    protected String uidOrigin;
    @XmlAttribute(name = "date-request")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dateRequest;
    @XmlAttribute(name = "async")
    protected Boolean async;
    @XmlAttribute(name = "eis-uuid")
    protected String eisUuid;
    @XmlAttribute(name = "timeout")
    protected Integer timeout;

    public Request() {
    }

    public Request(String service, String serviceVersion, String application, String operation, String user) {
        this.service = service;
        this.serviceVersion = serviceVersion;
        this.application = application;
        this.user = user;
        this.operation = operation;
    }

    /**
     * Gets the value of the parameters property.
     *
     * <p>
     * This accessor method returns a reference to the live list, not a
     * snapshot. Therefore any modification you make to the returned list will
     * be present inside the JAXB object. This is why there is not a
     * <CODE>set</CODE> method for the parameters property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getParameters().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Parameter }
     *
     *
     * @return
     */
    public List<Parameter> getParameters() {
        if (this.parameters == null) {
            this.parameters = new ArrayList<>();
        }
        return this.parameters;
    }

    public Request addParameter(Parameter parameter) {
        getParameters().add(parameter);
        return this;
    }

    /**
     * Obtiene el valor de la propiedad service.
     *
     * @return possible object is {@link String }
     *
     */
    public String getService() {
        return service;
    }

    /**
     * Define el valor de la propiedad service.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setService(String value) {
        this.service = value;
    }

    /**
     * Obtiene el valor de la propiedad serviceVersion.
     *
     * @return possible object is {@link String }
     *
     */
    public String getServiceVersion() {
        return serviceVersion;
    }

    /**
     * Define el valor de la propiedad serviceVersion.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setServiceVersion(String value) {
        this.serviceVersion = value;
    }

    /**
     * Obtiene el valor de la propiedad application.
     *
     * @return possible object is {@link String }
     *
     */
    public String getApplication() {
        return application;
    }

    /**
     * Define el valor de la propiedad application.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setApplication(String value) {
        this.application = value;
    }

    /**
     * Obtiene el valor de la propiedad user.
     *
     * @return possible object is {@link String }
     *
     */
    public String getUser() {
        return user;
    }

    /**
     * Define el valor de la propiedad user.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setUser(String value) {
        this.user = value;
    }

    /**
     * Obtiene el valor de la propiedad operation.
     *
     * @return possible object is {@link String }
     *
     */
    public String getOperation() {
        return operation;
    }

    /**
     * Define el valor de la propiedad operation.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setOperation(String value) {
        this.operation = value;
    }

    /**
     * Obtiene el valor de la propiedad uid.
     *
     * @return possible object is {@link String }
     *
     */
    public String getUid() {
        return uid;
    }

    /**
     * Define el valor de la propiedad uid.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setUid(String value) {
        this.uid = value;
    }

    /**
     * Obtiene el valor de la propiedad token.
     *
     * @return possible object is {@link String }
     *
     */
    public String getToken() {
        return token;
    }

    /**
     * Define el valor de la propiedad token.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setToken(String value) {
        this.token = value;
    }

    /**
     * Obtiene el valor de la propiedad uidOrigin.
     *
     * @return possible object is {@link String }
     *
     */
    public String getUidOrigin() {
        return uidOrigin;
    }

    /**
     * Define el valor de la propiedad uidOrigin.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setUidOrigin(String value) {
        this.uidOrigin = value;
    }

    /**
     * Obtiene el valor de la propiedad dateRequest.
     *
     * @return possible object is {@link XMLGregorianCalendar }
     *
     */
    public XMLGregorianCalendar getDateRequest() {
        return dateRequest;
    }

    /**
     * Define el valor de la propiedad dateRequest.
     *
     * @param value allowed object is {@link XMLGregorianCalendar }
     *
     */
    public void setDateRequest(XMLGregorianCalendar value) {
        this.dateRequest = value;
    }

    /**
     * Obtiene el valor de la propiedad async.
     *
     * @return possible object is {@link Boolean }
     *
     */
    public Boolean isAsync() {
        return async;
    }

    /**
     * Define el valor de la propiedad async.
     *
     * @param value allowed object is {@link Boolean }
     *
     */
    public void setAsync(Boolean value) {
        this.async = value;
    }

    /**
     * Obtiene el valor de la propiedad eisUuid.
     *
     * @return possible object is {@link String }
     *
     */
    public String getEisUuid() {
        return eisUuid;
    }

    /**
     * Define el valor de la propiedad eisUuid.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setEisUuid(String value) {
        this.eisUuid = value;
    }

    /**
     * Obtiene el valor de la propiedad timeout.
     *
     * @return possible object is {@link Integer }
     *
     */
    public Integer getTimeout() {
        return timeout;
    }

    /**
     * Define el valor de la propiedad timeout.
     *
     * @param value allowed object is {@link Integer }
     *
     */
    public void setTimeout(Integer value) {
        this.timeout = value;
    }

}
