
package com.promerica.customer.model.personalInfo;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "hasPublicSectorJob",
    "IsRelativeOfPublicSectorWorker",
    "compliesLocalLawRequirements"
})
@Generated("jsonschema2pojo")
public class PoliticallyExposedPerson {

    @JsonProperty("hasPublicSectorJob")
    private String hasPublicSectorJob;
    @JsonProperty("IsRelativeOfPublicSectorWorker")
    private String isRelativeOfPublicSectorWorker;
    @JsonProperty("compliesLocalLawRequirements")
    private String compliesLocalLawRequirements;
    @JsonIgnore
    

    @JsonProperty("hasPublicSectorJob")
    public String getHasPublicSectorJob() {
        return hasPublicSectorJob;
    }

    @JsonProperty("hasPublicSectorJob")
    public void setHasPublicSectorJob(String hasPublicSectorJob) {
        this.hasPublicSectorJob = hasPublicSectorJob;
    }

    @JsonProperty("IsRelativeOfPublicSectorWorker")
    public String getIsRelativeOfPublicSectorWorker() {
        return isRelativeOfPublicSectorWorker;
    }

    @JsonProperty("IsRelativeOfPublicSectorWorker")
    public void setIsRelativeOfPublicSectorWorker(String isRelativeOfPublicSectorWorker) {
        this.isRelativeOfPublicSectorWorker = isRelativeOfPublicSectorWorker;
    }

    @JsonProperty("compliesLocalLawRequirements")
    public String getCompliesLocalLawRequirements() {
        return compliesLocalLawRequirements;
    }

    @JsonProperty("compliesLocalLawRequirements")
    public void setCompliesLocalLawRequirements(String compliesLocalLawRequirements) {
        this.compliesLocalLawRequirements = compliesLocalLawRequirements;
    }

}
