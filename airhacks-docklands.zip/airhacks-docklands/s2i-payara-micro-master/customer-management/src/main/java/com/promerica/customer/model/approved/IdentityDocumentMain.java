
package com.promerica.customer.model.approved;

import java.io.Serializable;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "identityDocument"
})
@Generated("jsonschema2pojo")
public class IdentityDocumentMain implements Serializable
{
    @NotNull( message = "Ingrese Datos de documento.")
    @JsonProperty("identityDocument")
    @Valid
    private IdentityDocument identityDocument;
    private final static long serialVersionUID = 6762331091985412380L;

    /**
     * No args constructor for use in serialization
     * 
     */
    public IdentityDocumentMain() {
    }

    /**
     * 
     * @param identityDocument
     */
    public IdentityDocumentMain(IdentityDocument identityDocument) {
        super();
        this.identityDocument = identityDocument;
    }

    @JsonProperty("identityDocument")
    public IdentityDocument getIdentityDocument() {
        return identityDocument;
    }

    @JsonProperty("identityDocument")
    public void setIdentityDocument(IdentityDocument identityDocument) {
        this.identityDocument = identityDocument;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(IdentityDocumentMain.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("identityDocument");
        sb.append('=');
        sb.append(((this.identityDocument == null)?"<null>":this.identityDocument));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.identityDocument == null)? 0 :this.identityDocument.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof IdentityDocumentMain) == false) {
            return false;
        }
        IdentityDocumentMain rhs = ((IdentityDocumentMain) other);
        return ((this.identityDocument == rhs.identityDocument)||((this.identityDocument!= null)&&this.identityDocument.equals(rhs.identityDocument)));
    }

}
