
package com.promerica.customer.model.disclaimer;

import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "identityDocument",
    "fullName",
    "taxIdentityNumber"
})
@Generated("jsonschema2pojo")
public class PersonalInformation {

    @Valid
    @NotNull(message = "Debe incluir identityDocument.")
    @JsonProperty("identityDocument")
    private IdentityDocument identityDocument;
    @Valid
    @NotNull(message = "Debe incluir fullName.")
    @NotBlank(message = "fullName no puede estar en blanco.")
    @JsonProperty("fullName")
    private String fullName;
    @Valid
    @NotNull(message = "Debe incluir taxIdentityNumber.")
    @NotBlank(message = "taxIdentityNumber no puede estar en blanco.")
    @JsonProperty("taxIdentityNumber")
    private String taxIdentityNumber;

    @JsonProperty("identityDocument")
    public IdentityDocument getIdentityDocument() {
        return identityDocument;
    }

    @JsonProperty("identityDocument")
    public void setIdentityDocument(IdentityDocument identityDocument) {
        this.identityDocument = identityDocument;
    }

    @JsonProperty("fullName")
    public String getFullName() {
        return fullName;
    }

    @JsonProperty("fullName")
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    @JsonProperty("taxIdentityNumber")
    public String getTaxIdentityNumber() {
        return taxIdentityNumber;
    }

    @JsonProperty("taxIdentityNumber")
    public void setTaxIdentityNumber(String taxIdentityNumber) {
        this.taxIdentityNumber = taxIdentityNumber;
    }


}
