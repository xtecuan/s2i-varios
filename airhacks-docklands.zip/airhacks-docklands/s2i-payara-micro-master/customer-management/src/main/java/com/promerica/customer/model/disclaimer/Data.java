
package com.promerica.customer.model.disclaimer;

import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "disclaimer"
})
@Generated("jsonschema2pojo")
public class Data {

    @JsonProperty("disclaimer")
    private Disclaimer disclaimer;
    

    @JsonProperty("disclaimer")
    public Disclaimer getDisclaimer() {
        return disclaimer;
    }

    @JsonProperty("disclaimer")
    public void setDisclaimer(Disclaimer disclaimer) {
        this.disclaimer = disclaimer;
    }


}
