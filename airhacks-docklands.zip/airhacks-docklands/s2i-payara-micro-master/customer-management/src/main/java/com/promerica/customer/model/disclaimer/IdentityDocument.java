
package com.promerica.customer.model.disclaimer;

import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "number"
})
@Generated("jsonschema2pojo")
public class IdentityDocument {

    @Valid
    @NotNull(message = "Debe incluir number.")
    @NotBlank(message = "number no puede estar en blanco.")
    @JsonProperty("number")
    private String number;

    @JsonProperty("number")
    public String getNumber() {
        return number;
    }

    @JsonProperty("number")
    public void setNumber(String number) {
        this.number = number;
    }

}
