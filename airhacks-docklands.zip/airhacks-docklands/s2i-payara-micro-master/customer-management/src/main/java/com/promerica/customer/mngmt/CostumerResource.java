/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.promerica.customer.mngmt;

import com.promerica.customer.model.approved.Customer;
import com.promerica.customer.model.approved.Data;
import com.promerica.customer.model.approved.GetCustomerHasPreapprovedProducts;
import com.promerica.customer.model.approved.IdentityDocumentMain;
import com.promerica.customer.model.disclaimer.CustomerDisclaimer;
import com.promerica.customer.model.disclaimer.Disclaimer;
import com.promerica.customer.model.disclaimer.ResponseDisclaimer;
import com.promerica.customer.model.personalInfo.AddressInformation;
import com.promerica.customer.model.personalInfo.ContactInformation;
import com.promerica.customer.model.personalInfo.Country;
import com.promerica.customer.model.personalInfo.CustomerId;
import com.promerica.customer.model.personalInfo.CustomerPersonalInfo;
import com.promerica.customer.model.personalInfo.DocumentType;
import com.promerica.customer.model.personalInfo.FirstLevel;
import com.promerica.customer.model.personalInfo.IdentityDocument;
import com.promerica.customer.model.personalInfo.IssuerCountry;
import com.promerica.customer.model.personalInfo.OccupationInformation;
import com.promerica.customer.model.personalInfo.PersonalInformation;
import com.promerica.customer.model.personalInfo.SecondLevel;
import com.promerica.customer.utils.BaseException;
import com.promerica.customer.utils.NoDataFoundException;
import com.promerica.customer.utils.RequestScopedService;
import com.promerica.nosql.model.crud.MongoCrud;
import com.promerica.spi.client.core.Parameter;
import com.promerica.spi.client.core.Request;
import java.util.ArrayList;
import java.util.Date;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.apache.commons.jxpath.JXPathContext;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.GET;

/**
 *
 * @author Gabriel Bran <gabriel.bran@promerica.com.sv>
 */
@RequestScoped
@Path("customers")
@RolesAllowed({ "USER", "ADMIN" })
public class CostumerResource extends RequestScopedService {
    
    @Inject
    MongoCrud crud;
    
    @Inject
    @ConfigProperty(name = "datasource.mongo.dbname")
    private String dbName;

    @Inject
    protected transient Logger logger;
    
    @POST
    @Path("/get-has-preapproved-products")
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    public Response getCustomerHasPreapprovedProducts(IdentityDocumentMain document) throws BaseException, NoDataFoundException, NoDataFoundException {

        //TODO: AGREGAR EN INTERCEPTOR
        long start = System.currentTimeMillis();

        //logger.log(Level.INFO, "Issuer: " + callerPrincipal.getIssuer());
        //logger.log(Level.INFO, "User: " + callerPrincipal.getName());
        logger.log(Level.INFO, "Method: " + "/get-has-preapproved-products");
        logger.log(Level.INFO, "Inicia peticion {0}", uui);
        //logger.log(Level.INFO, host);
        //logger.log(Level.INFO, xOriginIpAddres);
        // TODO:
        // implementar validacion de headers de entrada.
        // implementar validacion de JWT.
        //
        // TODO: validar que el tipo de documento sea CIF.
        validateHeaders();
        validateModel(document);

        // 2. obtener peticion de reposotorio XML o construirla manualmente.
        //
        Request esbRequest = new Request(
                "SqlQuery", "1.0", "OTCRegional", "hasApprovedProductsSql",
                "usr_otc-regional")
                .addParameter(new Parameter(document.getIdentityDocument().getNumber(), "pcodcliente",
                        "java.lang.String", 1))
                .addParameter(new Parameter("TAR", "ptipoproducto",
                        "java.lang.String", 2));

        // 3. ejecutar servicio en spi.
        com.promerica.spi.client.core.Response esbResponse = esbClient.resolve(esbRequest);
        validateSpiResponse(esbResponse);
        
        // 4. procesar la respuesta spi para extraer los datos.
        JXPathContext jXPathContext = contextFrom(esbResponse);
        
        String hasPreApprovedProducts = (String) jXPathContext
                .getValue(
                        "collections[name='hasApprovedProductsSql']/entities[name='row-1']/attributes[name='HAS_PREAPROVED']/value");


        GetCustomerHasPreapprovedProducts response = new GetCustomerHasPreapprovedProducts();
        Data data = new Data();
        Customer customer = new Customer();
        customer.setHasPreApprovedProducts(Boolean.valueOf(hasPreApprovedProducts));
        data.setCustomer(customer);
        response.setData(data);
        
        long end = System.currentTimeMillis() - start;
        
        return defaultResponse(Response.ok(response), end).build();
    }
    
    @POST
    @Path("/get-auto-complete-info")
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    public Response getCustomerAutoCompleteInformation(IdentityDocumentMain document) throws BaseException, NoDataFoundException {
        
        long start = System.currentTimeMillis();
        
        validateHeaders();
        validateModel(document);
        
        Request esbRequest = new Request(
                "SqlQuery", "1.0", "OTCRegional", "obtenerInfoClientePreAprobSql",
                "usr_otc-regional")
                .addParameter(new Parameter(document.getIdentityDocument().getNumber(), "pcif",
                        "java.lang.String", 1));
        com.promerica.spi.client.core.Response esbResponse = esbClient.resolve(esbRequest);
        
        validateSpiResponse(esbResponse);
        
        JXPathContext jXPathContext = contextFrom(esbResponse);
        
        String dui = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='DUI']/value");
        
        String duiEmissionDate = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='FECEMIDUI']/value");
        
        String duiExpiry = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='FECVENDUI']/value");
        String firstName = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='PRIMER_NOMBRE']/value");
        String secondName = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='SEGUNDO_NOMBRE']/value");
        String firstSurname = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='PRIMER_APELLIDO']/value");
        String secondSurname = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='SEGUNDO_APELLIDO']/value");
        String marriedSurname = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='APELLIDO_CASADA']/value");
        String nationality = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='NACIONALIDAD']/value");;
        String codTipoIdDui = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='COD_TIPO_ID_DUI']/value");
        String email = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='EMAIL']/value");
        String phoneNumber = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='CELULAR']/value");
        String municipio = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='MUNIC']/value");
        String departamento = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='DEPARTAMENTO']/value");
        String physicalAddress = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='DIRECCION']/value");
        String physicalAddressLab = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='DIRECCIONLABORA']/value");
        String departamentoLab = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='DEPARTAMENTOLABORA']/value");
        String municipioLab = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='MUNICLABORA']/value");
        
        String pais = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='PAIS']/value");
        
        String paisLabora = (String) jXPathContext.getValue(
                "collections[name='obtenerInfoClientePreAprobSql']/entities[name='row-1']/attributes[name='PAISLABORA']/value");
        
        CustomerPersonalInfo customerPersonalInfo = new CustomerPersonalInfo();
        
        customerPersonalInfo.setData(new com.promerica.customer.model.personalInfo.Data());
        customerPersonalInfo.getData().setCustomer(new com.promerica.customer.model.personalInfo.Customer());
        customerPersonalInfo.getData().getCustomer().setPersonalInformation(new PersonalInformation());
        customerPersonalInfo.getData().getCustomer().getPersonalInformation().setIdentityDocument(new IdentityDocument());
        
        IdentityDocument idd = customerPersonalInfo.getData().getCustomer().getPersonalInformation().getIdentityDocument();
        idd.setNumber(dui);
        idd.setEmissionDate(duiEmissionDate);
        idd.setExpiryDate(duiExpiry);
        idd.setDocumentType(new DocumentType() {
            {
                setCode(codTipoIdDui);
                setName(codTipoIdDui);
            }
        });
        idd.setIssuerCountry(new IssuerCountry() {
            {
                setIsoCode(nationality);
            }
        });
        
        PersonalInformation pi = customerPersonalInfo.getData().getCustomer().getPersonalInformation();
        pi.setFirstName(firstName);
        pi.setSecondName(secondName);
        pi.setFirstSurname(firstSurname);
        pi.setSecondSurname(secondSurname);
        pi.setMarriedSurname(marriedSurname);
        pi.setNationality(nationality);
        
        customerPersonalInfo.getData().getCustomer().setContactInformation(new ContactInformation());
        ContactInformation contactinf = customerPersonalInfo.getData().getCustomer().getContactInformation();
        
        contactinf.setEmails(new ArrayList<String>() {
            {
                add(email);
            }
        });
        contactinf.setPhoneNumbers(new ArrayList<String>() {
            {
                add(phoneNumber);
            }
        });
        
        customerPersonalInfo.getData().getCustomer().setAddressInformation(new AddressInformation());
        AddressInformation addressInfo = customerPersonalInfo.getData().getCustomer().getAddressInformation();
        
        addressInfo.setFirstLevel(new FirstLevel() {
            {
                setCode(departamento);
            }
        });
        addressInfo.setSecondLevel(new SecondLevel() {
            {
                setCode(municipio);
            }
        });
        
        addressInfo.setPhysicalAddress(physicalAddress);
        
        addressInfo.setCountry(new  Country(){{ setIsoCode(pais); }});
        
        customerPersonalInfo.getData().getCustomer().setOccupationInformation(new OccupationInformation());
        OccupationInformation oi = customerPersonalInfo.getData().getCustomer().getOccupationInformation();
        oi.setAddressInformation(new AddressInformation());
        
        AddressInformation occupationAddressInfo = oi.getAddressInformation();
        
        occupationAddressInfo.setCountry(new Country() {
            {
                setIsoCode(paisLabora);
            }
        });
        occupationAddressInfo.setFirstLevel(new FirstLevel() {
            {
                setCode(departamentoLab);
            }
        });
        occupationAddressInfo.setSecondLevel(new SecondLevel() {
            {
                setCode(municipioLab);
            }
        });
        occupationAddressInfo.setPhysicalAddress(physicalAddressLab);
        
        long end = System.currentTimeMillis() - start;
        return defaultResponse(Response.ok(customerPersonalInfo), end).build();
    }
    
    @POST
    @Path("/get-address")
    public Response getCustomerAddress(IdentityDocumentMain document) throws BaseException, NoDataFoundException {
        
        long start = System.currentTimeMillis();
        
        validateHeaders();
        validateModel(document);
        
        Request esbRequest = new Request(
                "SqlQuery", "1.0", "OTCRegional", "obtenerDireccionClienteSql",
                "usr_otc-regional")
                .addParameter(new Parameter(document.getIdentityDocument().getNumber(), "pcif",
                        "java.lang.String", 1));
        com.promerica.spi.client.core.Response esbResponse = esbClient.resolve(esbRequest);
        
        validateSpiResponse(esbResponse);
        
        JXPathContext jXPathContext = contextFrom(esbResponse);
        
        String physicalAddress = (String) jXPathContext.getValue(
                "collections[name='obtenerDireccionClienteSql']/entities[name='row-1']/attributes[name='DIRECCION']/value");
        String municipio = (String) jXPathContext.getValue(
                "collections[name='obtenerDireccionClienteSql']/entities[name='row-1']/attributes[name='MUNIC']/value");
        String departamento = (String) jXPathContext.getValue(
                "collections[name='obtenerDireccionClienteSql']/entities[name='row-1']/attributes[name='DEPARTAMENTO']/value");
        String pais = (String) jXPathContext.getValue(
                "collections[name='obtenerDireccionClienteSql']/entities[name='row-1']/attributes[name='PAIS']/value");
        String physicalAddressLab = (String) jXPathContext.getValue(
                "collections[name='obtenerDireccionClienteSql']/entities[name='row-1']/attributes[name='DIRECCIONLABORA']/value");
        String municipioLab = (String) jXPathContext.getValue(
                "collections[name='obtenerDireccionClienteSql']/entities[name='row-1']/attributes[name='MUNICLABORA']/value");
        String departamentoLab = (String) jXPathContext.getValue(
                "collections[name='obtenerDireccionClienteSql']/entities[name='row-1']/attributes[name='DEPARTAMENTOLABORA']/value");
        String paisLab = (String) jXPathContext.getValue(
                "collections[name='obtenerDireccionClienteSql']/entities[name='row-1']/attributes[name='PAISLABORA']/value");
        
        
        CustomerPersonalInfo customerPersonalInfo = new CustomerPersonalInfo();
        
        customerPersonalInfo.setData(new com.promerica.customer.model.personalInfo.Data());
        customerPersonalInfo.getData().setCustomer(new com.promerica.customer.model.personalInfo.Customer());
        
        customerPersonalInfo.getData().getCustomer().setAddressInformation(new AddressInformation());
        AddressInformation addressInfo = customerPersonalInfo.getData().getCustomer().getAddressInformation();
        
        addressInfo.setCountry(new Country() {
            {
                setIsoCode(pais);
            }
        });
        addressInfo.setFirstLevel(new FirstLevel() {
            {
                setCode(departamento);
            }
        });
        addressInfo.setSecondLevel(new SecondLevel() {
            {
                setCode(municipio);
            }
        });
        
        addressInfo.setPhysicalAddress(physicalAddress);
        
        customerPersonalInfo.getData().getCustomer().setOccupationInformation(new OccupationInformation());
        OccupationInformation oi = customerPersonalInfo.getData().getCustomer().getOccupationInformation();
        oi.setAddressInformation(new AddressInformation());
        
        AddressInformation occupationAddressInfo = oi.getAddressInformation();
        
        occupationAddressInfo.setCountry(new Country() {
            {
                setIsoCode(paisLab);
            }
        });
        occupationAddressInfo.setFirstLevel(new FirstLevel() {
            {
                setCode(departamentoLab);
            }
        });
        occupationAddressInfo.setSecondLevel(new SecondLevel() {
            {
                setCode(municipioLab);
            }
        });
        occupationAddressInfo.setPhysicalAddress(physicalAddressLab);
        
        long end = System.currentTimeMillis() - start;
        
        return defaultResponse(Response.ok(customerPersonalInfo), end).build();

    }
    
    @PUT
    @Path("/upd-address")
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    public Response updateCustomerAddress(com.promerica.customer.model.personalInfo.Customer customer) throws BaseException {
        long start = System.currentTimeMillis();
        
        validateHeaders();
        validateModel(customer);
        /*Se genera ID a partir de numero de documento y el tipo en mayusculas*/
        customer.setId( new CustomerId(customer.getPersonalInformation().getIdentityDocument().getNumber(),customer.getPersonalInformation().getIdentityDocument().getDocumentType().getCode().toUpperCase()));
        crud.insert(customer);
        
        long end = System.currentTimeMillis() - start;
        
        return defaultResponse(Response.ok(), end).build();
    }
    
    @POST
    @Path("/disclaimers/add")
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    public Response addDisclaimer(CustomerDisclaimer customerDisclaimer) throws BaseException {
        long start = System.currentTimeMillis();
        String uid = uui;
        logger.log(Level.INFO,"Inicia peticion: {0}", new Object[]{ uui });
        validateHeaders();
        validateModel(customerDisclaimer);
        
        com.promerica.customer.model.disclaimer.Data data = new com.promerica.customer.model.disclaimer.Data();
        
        Disclaimer disclaimer = new Disclaimer();
        
        disclaimer.setId(uid);
        
        data.setDisclaimer(disclaimer);
        
        ResponseDisclaimer responseDisclaimer = new ResponseDisclaimer();
        responseDisclaimer.setData(data);
        
        customerDisclaimer.setResponseDisclaimer(responseDisclaimer);
        
        customerDisclaimer.setDate(new Date());
        
        customerDisclaimer.setId(uid);
        
        crud.insert(customerDisclaimer);
        long end = System.currentTimeMillis() - start;
        return defaultResponse(Response.ok(responseDisclaimer), end).build();
    }

    
    @GET
    @Path("/nosql/test")
    public Response test(){
        
        /*
        //create
        Contrato c = new Contrato();
        //c.setId("123456789");
        c.setCanal("SC");
        c.setCif("0145678910");
        c.setFecha(new Date().toString());
        c.setNombre("NOMBRE CLIENTE DE PRUEBA");
        c.setAceptoPlanPromerica("N");
        c=crud.insert(c);
        
        c.setNombre("NOMBRE MODIFICADO");
        
        //update
        crud.update(c);
        
        //findBydId
        c = crud.findById(c.getId(), Contrato.class);
        
        //Build Query
        Query<Contrato> con = crud.query(Contrato.class);
        
        List<Contrato> r=con.filter(Filters.eq("nombre", "NOMBRE MODIFICADO")).iterator().toList();
        
        //delete
        crud.delete(c.getId(), Contrato.class);
        */
        return Response.ok(crud.findById(new CustomerId("03532126-1","DUI" ), com.promerica.customer.model.personalInfo.Customer.class)).build();
    
    }
     
}
