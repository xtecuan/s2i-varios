/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.promerica.nosql.model.crud;


import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Inject;

import com.mongodb.client.result.DeleteResult;
import com.promerica.nosql.config.MongoConnection;

import org.eclipse.microprofile.config.inject.ConfigProperty;

import dev.morphia.Datastore;
import dev.morphia.DeleteOptions;
import dev.morphia.query.Query;
import dev.morphia.query.experimental.filters.Filters;
import org.bson.Document;

/**
 *
 * @author megarcia
 */
@Stateless
public class MongoCrud {

    @Inject
    private MongoConnection mongoConnection;
    
    @Inject
    @ConfigProperty(name = "datasource.mongo.dbname")
    private String dbName;
    
    Datastore ds;
    
    MongoDatabase database;
    
    @PostConstruct
    private void _init(){
        ds=mongoConnection.getDataStore(dbName);
        database = mongoConnection.getDatabase(dbName);
    }

    public <T> T insert(T type){
        ds.save(type);
        return type;
    }
      
    public <T> T update(T type){
        return insert(type);
    }
    
    public <T> T findById(String id, Class<T> type){
        return (T)ds.find(type).filter(Filters.eq("_id", id)).iterator().tryNext();
    }
    
    public <T> T findById(Object id, Class<T> type){
        return (T)ds.find(type).filter(Filters.eq("_id", id)).iterator().tryNext();
    }
    
    public <T>boolean delete(String id, Class<T> type){
        DeleteResult result= ds.find(type).filter(Filters.eq("_id", id)).delete(new DeleteOptions().multi(false));
        return result.getDeletedCount() > 0 ;
    }
    
    public <T> Query<T> query(Class<T> type){
        return ds.find(type);
    }
    
    
    
    public <T> T insert(T type, String collection) {
        MongoCollection<T> collectionStore = (MongoCollection<T>) database.getCollection(collection, type.getClass());
        collectionStore.insertOne(type);
        return (T) type;
    }

    /*
    public <T> T findById(String collection, ObjectId oid, Class<T> type) {
        Optional<MongoDatabase> database = mongoConnection.tryInstance(dbName);
        MongoCollection<T> collectionStore = (MongoCollection<T>)database.get().getCollection(collection, type.getClass());
        BasicDBObject query = new BasicDBObject();
        query.append("_id", oid);
        T t = (T) collectionStore.find(query).first();
        return t;
    }

    public <T> T findById(String collection, String id, Class<T> type) {
        Optional<MongoDatabase> database = mongoConnection.tryInstance(dbName);
        MongoCollection<T> collectionStore = (MongoCollection<T>)database.get().getCollection(collection);
        BasicDBObject query = new BasicDBObject();
        query.append("_id", new ObjectId(id));
        T t = (T) collectionStore.find(query).first();
        return t;
    }

    public boolean delete(String collection, String id) {
        Optional<MongoDatabase> database = mongoConnection.tryInstance(dbName);
        MongoCollection<Document> collectionStore = database.get().getCollection(collection);
        BasicDBObject query = new BasicDBObject();
        query.append("_id", new ObjectId(id));
        DeleteResult r = collectionStore.deleteOne(query);
        return (r.getDeletedCount() > 0);
    }*/
    
}
