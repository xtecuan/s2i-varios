
package com.promerica.customer.model.personalInfo;

import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "isoCode"
})
@Generated("jsonschema2pojo")
public class Country {

    @Valid
    @NotNull(message = "Debe incluir isoCode")
    @NotBlank(message = "isoCode no puede estar en blanco.")
    @JsonProperty("isoCode")
    private String isoCode;
    @JsonIgnore
    

    @JsonProperty("isoCode")
    public String getIsoCode() {
        return isoCode;
    }

    @JsonProperty("isoCode")
    public void setIsoCode(String isoCode) {
        this.isoCode = isoCode;
    }

}
