/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.promerica.customer.utils;

import java.util.UUID;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Produces;

/**
 *
 * @author megarcia <megarcia@promerica.com.sv>
 */
@RequestScoped
public class UuidProducer {

    @Produces
    public String getUuid() {
        UUID uui = UUID.randomUUID();
        return uui.toString();
    }
}
