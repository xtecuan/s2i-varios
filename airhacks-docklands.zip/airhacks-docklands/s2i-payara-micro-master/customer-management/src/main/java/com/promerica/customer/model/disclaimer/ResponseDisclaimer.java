
package com.promerica.customer.model.disclaimer;

import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;

import javax.json.bind.annotation.JsonbProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "Data"
})
@Generated("jsonschema2pojo")
public class ResponseDisclaimer {

    @JsonbProperty("Data")
    private Data data;
    

    @JsonbProperty("Data")
    public Data getData() {
        return data;
    }

    @JsonbProperty("Data")
    public void setData(Data data) {
        this.data = data;
    }

}
