/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.promerica.nosql.config;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import dev.morphia.Datastore;
import dev.morphia.Morphia;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.decorators.Decorators;
import io.vavr.control.Try;
import java.time.Duration;
import java.util.Optional;
import java.util.function.Supplier;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.Singleton;
import javax.inject.Inject;
import static org.bson.codecs.configuration.CodecRegistries.fromProviders;
import static org.bson.codecs.configuration.CodecRegistries.fromRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;
import org.eclipse.microprofile.config.inject.ConfigProperty;

/**
 *
 * @author Daniel Ortiz <deortiz@promerica.com.sv>
 */
@Singleton
public class MongoConnection {

    @Inject
    @ConfigProperty(name = "ds_password", defaultValue = "")
    private String mongoPass;
    @Inject
    @ConfigProperty(name = "ds_user", defaultValue = "")
    private String mongoUser;
    @Inject
    @ConfigProperty(name = "datasource.mongo.host", defaultValue = "")
    private String mongoHost;
    @Inject
    @ConfigProperty(name = "datasource.mongo.port", defaultValue = "")
    private String mongoPort;
    @Inject
    @ConfigProperty(name = "datasource.mongo.test.collection", defaultValue = "")
    private String mongoTestCollection;

    @Inject
    @ConfigProperty(name = "datasource.mongo.dbname")
    private String dbName;

    private Datastore datastore;
    private MongoDatabase database;

    @PostConstruct
    private void _init() {
        StringBuilder mongoUri = new StringBuilder().append("mongodb://")
                .append(mongoUser)
                .append(":").append(mongoPass)
                .append("@").append(mongoHost)
                .append(":").append(mongoPort)
                .append("/?authSource=")
                .append(dbName);
        
        CodecRegistry pojoCodecRegistry = fromRegistries(MongoClientSettings.getDefaultCodecRegistry(), fromProviders(PojoCodecProvider.builder().automatic(true).build()));

        MongoClientSettings settings = MongoClientSettings.builder().codecRegistry(pojoCodecRegistry).applyConnectionString(new ConnectionString(mongoUri.toString())).build(); 
        
        MongoClient mc = MongoClients.create(settings);
        
        this.datastore = Morphia.createDatastore(mc, dbName);
        datastore.getMapper().mapPackage("com.promerica.nosql.model.entities");
        datastore.ensureIndexes();

        database = mc.getDatabase(dbName);
        MongoCollection collection = database.getCollection(mongoTestCollection);//test collection
        collection.countDocuments();

    }

    public Optional<Datastore> tryInstance(String databaseName) {

        CircuitBreakerConfig circuitBreakerConfig = CircuitBreakerConfig.custom()
                .failureRateThreshold(40f)
                .slidingWindowSize(10)
                .slidingWindowType(CircuitBreakerConfig.SlidingWindowType.COUNT_BASED)
                .permittedNumberOfCallsInHalfOpenState(10)
                .waitDurationInOpenState(Duration.ofMillis(5000))
                .build();
        CircuitBreakerRegistry circuitBreakerRegistry
                = CircuitBreakerRegistry.of(circuitBreakerConfig);
        CircuitBreaker circuitBreaker = circuitBreakerRegistry
                .circuitBreaker("mongoCircuitBreaker");
        Supplier<Datastore> decoratedSupplier = () -> getDataStore(databaseName);
        Supplier<Datastore> decoratedSupplierDecorated = Decorators.ofSupplier(decoratedSupplier)
                .withCircuitBreaker(circuitBreaker).decorate();

        Datastore instance = Try.ofSupplier(decoratedSupplierDecorated)
                .recover(throwable -> null).get();
        return Optional.ofNullable(instance);
    }

    public MongoDatabase getDatabase(String databaseName) {
        //chequear la conexion
        return this.database;
    }

    public Datastore getDataStore(String databaseName) {
        return this.datastore;
    }

}
