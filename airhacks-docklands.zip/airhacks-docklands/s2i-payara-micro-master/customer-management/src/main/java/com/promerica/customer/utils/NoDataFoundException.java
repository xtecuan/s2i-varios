/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.promerica.customer.utils;

import com.promerica.customer.model.ErrorBase;

/**
 *
 * @author Miguel Garcia <megarcia@promerica.com.sv>
 */
public class NoDataFoundException extends Exception{
    
    private ErrorBase error;
    
    /**
     * Constructs an instance of <code>BaseException</code> with the specified
     * detail message.
     *
     * @param msg the detail message.
     */
    public NoDataFoundException(String msg) {
        super(msg);
    }

    /**
     * Constructs an instance of <code>BaseException</code> with the specified
     * detail error.
     *
     * @param error the detail message.
     */
    public NoDataFoundException(ErrorBase error) {
        this.error = error;
    }

    public ErrorBase getError() {
        return error;
    }
    
}
