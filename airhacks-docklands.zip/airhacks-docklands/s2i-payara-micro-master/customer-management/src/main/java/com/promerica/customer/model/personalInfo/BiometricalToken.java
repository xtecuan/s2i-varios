
package com.promerica.customer.model.personalInfo;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "ocr",
    "frontDocument",
    "backDocument",
    "faceImage",
    "rawFrontDocument",
    "rawBackDocument",
    "digitalSing"
})
@Generated("jsonschema2pojo")
public class BiometricalToken {

    @JsonProperty("ocr")
    private String ocr;
    @JsonProperty("frontDocument")
    private String frontDocument;
    @JsonProperty("backDocument")
    private String backDocument;
    @JsonProperty("faceImage")
    private String faceImage;
    @JsonProperty("rawFrontDocument")
    private String rawFrontDocument;
    @JsonProperty("rawBackDocument")
    private String rawBackDocument;
    @JsonProperty("digitalSing")
    private String digitalSing;
    

    @JsonProperty("ocr")
    public String getOcr() {
        return ocr;
    }

    @JsonProperty("ocr")
    public void setOcr(String ocr) {
        this.ocr = ocr;
    }

    @JsonProperty("frontDocument")
    public String getFrontDocument() {
        return frontDocument;
    }

    @JsonProperty("frontDocument")
    public void setFrontDocument(String frontDocument) {
        this.frontDocument = frontDocument;
    }

    @JsonProperty("backDocument")
    public String getBackDocument() {
        return backDocument;
    }

    @JsonProperty("backDocument")
    public void setBackDocument(String backDocument) {
        this.backDocument = backDocument;
    }

    @JsonProperty("faceImage")
    public String getFaceImage() {
        return faceImage;
    }

    @JsonProperty("faceImage")
    public void setFaceImage(String faceImage) {
        this.faceImage = faceImage;
    }

    @JsonProperty("rawFrontDocument")
    public String getRawFrontDocument() {
        return rawFrontDocument;
    }

    @JsonProperty("rawFrontDocument")
    public void setRawFrontDocument(String rawFrontDocument) {
        this.rawFrontDocument = rawFrontDocument;
    }

    @JsonProperty("rawBackDocument")
    public String getRawBackDocument() {
        return rawBackDocument;
    }

    @JsonProperty("rawBackDocument")
    public void setRawBackDocument(String rawBackDocument) {
        this.rawBackDocument = rawBackDocument;
    }

    @JsonProperty("digitalSing")
    public String getDigitalSing() {
        return digitalSing;
    }

    @JsonProperty("digitalSing")
    public void setDigitalSing(String digitalSing) {
        this.digitalSing = digitalSing;
    }

}
