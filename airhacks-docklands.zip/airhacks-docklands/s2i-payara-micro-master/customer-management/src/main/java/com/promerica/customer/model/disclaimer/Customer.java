
package com.promerica.customer.model.disclaimer;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "personalInformation"
})
@Generated("jsonschema2pojo")
public class Customer {

    @JsonProperty("personalInformation")
    private PersonalInformation personalInformation;

    @Valid
    @NotNull(message = "Debe incluir personalInformation.")
    @JsonProperty("personalInformation")
    public PersonalInformation getPersonalInformation() {
        return personalInformation;
    }

    @JsonProperty("personalInformation")
    public void setPersonalInformation(PersonalInformation personalInformation) {
        this.personalInformation = personalInformation;
    }

}
