
package com.promerica.customer.model.personalInfo;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "isoCode"
})
@Generated("jsonschema2pojo")
public class IssuerCountry {

    @JsonProperty("isoCode")
    private String isoCode;
    @JsonIgnore
    

    @JsonProperty("isoCode")
    public String getIsoCode() {
        return isoCode;
    }

    @JsonProperty("isoCode")
    public void setIsoCode(String isoCode) {
        this.isoCode = isoCode;
    }

}
