
package com.promerica.customer.model.disclaimer;

import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "code"
})
@Generated("jsonschema2pojo")
public class ContractType {

    @Valid
    @NotNull(message = "Debe incluir code.")
    @NotBlank(message = "code no debe estar vacio.")
    @JsonProperty("code")
    private String code;

    @JsonProperty("code")
    public String getCode() {
        return code;
    }

    @JsonProperty("code")
    public void setCode(String code) {
        this.code = code;
    }


}
