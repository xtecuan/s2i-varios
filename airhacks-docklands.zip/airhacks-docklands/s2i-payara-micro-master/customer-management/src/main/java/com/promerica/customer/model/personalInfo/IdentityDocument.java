
package com.promerica.customer.model.personalInfo;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "number",
    "expiryDate",
    "emissionDate",
    "documentType",
    "issuerCountry",
    "politicallyExposedPerson",
    "biometricalToken"
})
@Generated("jsonschema2pojo")
public class IdentityDocument {

    @Valid
    @NotNull( message = "Debe incluir number.")
    @NotBlank(message = "number no puede estar en blanco.")
    @JsonProperty("number")
    private String number;
    @JsonProperty("expiryDate")
    private String expiryDate;
    @JsonProperty("emissionDate")
    private String emissionDate;
    @Valid
    @NotNull(message = "Debe incluir documentType.")
    @JsonProperty("documentType")
    private DocumentType documentType;
    @JsonProperty("issuerCountry")
    private IssuerCountry issuerCountry;
    @JsonProperty("politicallyExposedPerson")
    private PoliticallyExposedPerson politicallyExposedPerson;
    @JsonProperty("biometricalToken")
    private BiometricalToken biometricalToken;
    @JsonIgnore
    

    @JsonProperty("number")
    public String getNumber() {
        return number;
    }

    @JsonProperty("number")
    public void setNumber(String number) {
        this.number = number;
    }

    @JsonProperty("expiryDate")
    public String getExpiryDate() {
        return expiryDate;
    }

    @JsonProperty("expiryDate")
    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    @JsonProperty("emissionDate")
    public String getEmissionDate() {
        return emissionDate;
    }

    @JsonProperty("emissionDate")
    public void setEmissionDate(String emissionDate) {
        this.emissionDate = emissionDate;
    }

    @JsonProperty("documentType")
    public DocumentType getDocumentType() {
        return documentType;
    }

    @JsonProperty("documentType")
    public void setDocumentType(DocumentType documentType) {
        this.documentType = documentType;
    }

    @JsonProperty("issuerCountry")
    public IssuerCountry getIssuerCountry() {
        return issuerCountry;
    }

    @JsonProperty("issuerCountry")
    public void setIssuerCountry(IssuerCountry issuerCountry) {
        this.issuerCountry = issuerCountry;
    }

    @JsonProperty("politicallyExposedPerson")
    public PoliticallyExposedPerson getPoliticallyExposedPerson() {
        return politicallyExposedPerson;
    }

    @JsonProperty("politicallyExposedPerson")
    public void setPoliticallyExposedPerson(PoliticallyExposedPerson politicallyExposedPerson) {
        this.politicallyExposedPerson = politicallyExposedPerson;
    }

    @JsonProperty("biometricalToken")
    public BiometricalToken getBiometricalToken() {
        return biometricalToken;
    }

    @JsonProperty("biometricalToken")
    public void setBiometricalToken(BiometricalToken biometricalToken) {
        this.biometricalToken = biometricalToken;
    }

}
