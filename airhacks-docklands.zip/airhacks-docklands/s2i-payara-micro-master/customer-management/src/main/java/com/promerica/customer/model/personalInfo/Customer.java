
package com.promerica.customer.model.personalInfo;

import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;
import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonbPropertyOrder({
    "personalInformation",
    "contactInformation",
    "addressInformation",
    "referencesInformation",
    "occupationInformation"
})
@Generated("jsonschema2pojo")
@Entity("customer-addresses")
public class Customer {

    @JsonIgnore
    @Id
    private CustomerId id;
    @Valid
    @NotNull(message = "Debe incluir personalInformation.")
    @JsonProperty("personalInformation")
    private PersonalInformation personalInformation;
    @JsonProperty("contactInformation")
    private ContactInformation contactInformation;
    @JsonProperty("addressInformation")
    @Valid
    @NotNull(message = "Debe incluir AddressInformation.")
    private AddressInformation addressInformation;
    @JsonProperty("referencesInformation")
    private List<ReferencesInformation> referencesInformation = null;
    @Valid
    @NotNull(message = "Debe incluir occupationInformation.")
    @JsonProperty("occupationInformation")
    private OccupationInformation occupationInformation;
    @JsonIgnore
    

    @JsonProperty("personalInformation")
    public PersonalInformation getPersonalInformation() {
        return personalInformation;
    }

    @JsonProperty("personalInformation")
    public void setPersonalInformation(PersonalInformation personalInformation) {
        this.personalInformation = personalInformation;
    }

    @JsonProperty("contactInformation")
    public ContactInformation getContactInformation() {
        return contactInformation;
    }

    @JsonProperty("contactInformation")
    public void setContactInformation(ContactInformation contactInformation) {
        this.contactInformation = contactInformation;
    }

    @JsonProperty("addressInformation")
    public AddressInformation getAddressInformation() {
        return addressInformation;
    }

    @JsonProperty("addressInformation")
    public void setAddressInformation(AddressInformation addressInformation) {
        this.addressInformation = addressInformation;
    }

    @JsonProperty("referencesInformation")
    public List<ReferencesInformation> getReferencesInformation() {
        return referencesInformation;
    }

    @JsonProperty("referencesInformation")
    public void setReferencesInformation(List<ReferencesInformation> referencesInformation) {
        this.referencesInformation = referencesInformation;
    }

    @JsonProperty("occupationInformation")
    public OccupationInformation getOccupationInformation() {
        return occupationInformation;
    }

    @JsonProperty("occupationInformation")
    public void setOccupationInformation(OccupationInformation occupationInformation) {
        this.occupationInformation = occupationInformation;
    }
    
    @JsonProperty("id")
    public CustomerId getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(CustomerId id) {
        this.id = id;
    }

}
