#!/bin/bash

export DNAME="CN=localhost, OU=IT, O=Banco Promerica, L=Antiguo Cuscatlan, ST=La Libertad, C=SV"
export ALIAS=s1as
export EXT="SAN=IP:10.5.15.81,IP:127.0.0.1,DNS:EGV-5760-1581.promnet.com.sv,DNS:localhost,EMAIL:jurivera@promerica.com.sv"
export PASS=changeit

keytool -genkeypair -storepass ${PASS} -storetype PKCS12 -keyalg RSA -keysize 2048 -dname "${DNAME}" -alias ${ALIAS} -ext "${EXT}" -keystore src/main/resources/MICRO-INF/domain/config/keystore.jks