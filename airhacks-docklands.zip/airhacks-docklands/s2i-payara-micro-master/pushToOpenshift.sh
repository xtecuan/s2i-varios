#!/bin/bash


docker push default-route-openshift-image-registry.apps.ocp01.promnet.com.sv/pruebadev/s2i-payara-micro-promerica-new
